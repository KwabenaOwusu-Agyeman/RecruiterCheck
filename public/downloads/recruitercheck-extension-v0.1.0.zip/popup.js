// src/config.ts
var WEB_APP_URL = "https://myrecruitercheck.com";

// src/popup/popup.ts
var root = document.getElementById("root");
function sendMessage(message) {
  return chrome.runtime.sendMessage(message);
}
function render(state) {
  root.innerHTML = "";
  switch (state.kind) {
    case "loading":
      root.appendChild(textNode("Loading\u2026"));
      break;
    case "not_connected":
      root.appendChild(
        buildScreen({
          tagline: "See your application from a recruiter's perspective.",
          primaryLabel: "Connect MyRecruiterCheck",
          onPrimary: onConnect
        })
      );
      break;
    case "connecting":
      root.appendChild(textNode("Connecting\u2026"));
      break;
    case "connect_error":
      root.appendChild(
        buildScreen({
          errorMessage: state.message,
          primaryLabel: "Connect MyRecruiterCheck",
          onPrimary: onConnect
        })
      );
      break;
    case "ready":
      root.appendChild(
        buildScreen({
          tagline: "See your application from a recruiter's perspective.",
          primaryLabel: "Capture this job",
          onPrimary: onCapture
        })
      );
      break;
    case "capturing":
      root.appendChild(textNode("Reading this job\u2026"));
      break;
    case "preview": {
      const { capture } = state;
      const wrap = document.createElement("div");
      if (capture.jobTitle) {
        const label = document.createElement("p");
        label.className = "field-label";
        label.textContent = "Job title";
        wrap.appendChild(label);
        const title = document.createElement("p");
        title.className = "job-title";
        title.textContent = capture.jobTitle;
        wrap.appendChild(title);
      }
      if (capture.companyName) {
        const company = document.createElement("p");
        company.className = "job-company";
        company.textContent = capture.companyName;
        wrap.appendChild(company);
      }
      const status = document.createElement("p");
      status.className = "status-line";
      status.textContent = "Job description captured \u2713";
      wrap.appendChild(status);
      const primary = document.createElement("button");
      primary.className = "btn btn-primary";
      primary.textContent = "Check this job";
      primary.addEventListener("click", () => void onSubmit(capture));
      wrap.appendChild(primary);
      root.appendChild(wrap);
      break;
    }
    case "capture_failed":
      root.appendChild(
        buildScreen({
          tagline: "We couldn't confidently read this job.",
          primaryLabel: "Open MyRecruiterCheck",
          onPrimary: onOpenNewCheck
        })
      );
      break;
    case "submitting":
      root.appendChild(textNode("Sending to MyRecruiterCheck\u2026"));
      break;
    case "submit_error":
      root.appendChild(
        buildScreen({
          errorMessage: state.message,
          primaryLabel: state.reconnect ? "Reconnect MyRecruiterCheck" : "Try again",
          onPrimary: state.reconnect ? onConnect : onCapture
        })
      );
      break;
    case "submitted":
      root.appendChild(textNode("Opened in MyRecruiterCheck. You can close this popup."));
      break;
  }
}
function textNode(text) {
  const p = document.createElement("p");
  p.className = "center-text";
  p.textContent = text;
  return p;
}
function buildScreen(opts) {
  const wrap = document.createElement("div");
  if (opts.tagline) {
    const p = document.createElement("p");
    p.className = "tagline";
    p.textContent = opts.tagline;
    wrap.appendChild(p);
  }
  if (opts.errorMessage) {
    const box = document.createElement("div");
    box.className = "error-box";
    box.textContent = opts.errorMessage;
    wrap.appendChild(box);
  }
  const button = document.createElement("button");
  button.className = "btn btn-primary";
  button.textContent = opts.primaryLabel;
  button.addEventListener("click", opts.onPrimary);
  wrap.appendChild(button);
  return wrap;
}
async function onConnect() {
  render({ kind: "connecting" });
  const response = await sendMessage({ type: "CONNECT" });
  if (response.ok) {
    render({ kind: "ready" });
  } else {
    render({ kind: "connect_error", message: response.error });
  }
}
async function onCapture() {
  render({ kind: "capturing" });
  const response = await sendMessage({ type: "CAPTURE_ACTIVE_TAB" });
  if (!response.ok) {
    render({ kind: "capture_failed" });
    return;
  }
  if (response.result.ok) {
    render({ kind: "preview", capture: response.result.capture });
  } else {
    render({ kind: "capture_failed" });
  }
}
async function onSubmit(capture) {
  render({ kind: "submitting" });
  const response = await sendMessage({ type: "SUBMIT_CAPTURE", capture });
  if (response.ok) {
    render({ kind: "submitted" });
    return;
  }
  const reconnect = response.error === "Unauthorized";
  render({
    kind: "submit_error",
    message: reconnect ? "Your MyRecruiterCheck connection expired." : response.error,
    reconnect
  });
}
function onOpenNewCheck() {
  chrome.tabs.create({ url: `${WEB_APP_URL}/checks/new` });
}
async function init() {
  render({ kind: "loading" });
  const session = await sendMessage({ type: "GET_SESSION" });
  render(session.connected ? { kind: "ready" } : { kind: "not_connected" });
}
void init();
