"use strict";
(() => {
  // src/capture/detect.ts
  function detectSourceDomain(hostname) {
    const host = hostname.toLowerCase();
    if (/(^|\.)linkedin\.com$/.test(host)) return "linkedin";
    if (/(^|\.)indeed\.com$/.test(host)) return "indeed";
    return "other";
  }
  var NOISE_SELECTORS = [
    "nav",
    "header",
    "footer",
    "aside",
    "script",
    "style",
    "noscript",
    "form",
    "iframe",
    '[class*="cookie" i]',
    '[class*="consent" i]',
    '[class*="advertisement" i]',
    '[class*="related-job" i]',
    '[class*="recommended-job" i]',
    '[class*="similar-job" i]',
    '[id*="cookie" i]'
  ];
  function cleanText(raw) {
    return raw.replace(/\s+/g, " ").trim();
  }
  function queryText(root, selectors) {
    for (const selector of selectors) {
      const el = root.querySelector(selector);
      if (!el) continue;
      if (NOISE_SELECTORS.some((noise) => el.closest(noise))) continue;
      const text = cleanText(el.textContent ?? "");
      if (text) return text;
    }
    return null;
  }

  // src/capture/jsonld.ts
  function stripHtml(html) {
    return cleanText(
      html.replace(/<(script|style)[^>]*>[\s\S]*?<\/\1>/gi, " ").replace(/<br\s*\/?>/gi, "\n").replace(/<\/(p|li|div)>/gi, "\n").replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&#39;/g, "'").replace(/&quot;/g, '"')
    );
  }
  function findJobPosting(value) {
    if (Array.isArray(value)) {
      for (const item of value) {
        const found = findJobPosting(item);
        if (found) return found;
      }
      return null;
    }
    if (value && typeof value === "object") {
      const obj = value;
      const type = obj["@type"];
      const typeMatches = typeof type === "string" && type.toLowerCase() === "jobposting" || Array.isArray(type) && type.some((t) => typeof t === "string" && t.toLowerCase() === "jobposting");
      if (typeMatches) return obj;
      if ("@graph" in obj) return findJobPosting(obj["@graph"]);
    }
    return null;
  }
  function extractJobPostingJsonLd(doc) {
    const scripts = doc.querySelectorAll('script[type="application/ld+json"]');
    for (const script of Array.from(scripts)) {
      let parsed;
      try {
        parsed = JSON.parse(script.textContent ?? "");
      } catch {
        continue;
      }
      const posting = findJobPosting(parsed);
      if (!posting) continue;
      const title = typeof posting.title === "string" ? cleanText(posting.title) : null;
      let companyName = null;
      const org = posting.hiringOrganization;
      if (org && typeof org === "object" && typeof org.name === "string") {
        companyName = cleanText(org.name);
      }
      const description = typeof posting.description === "string" ? stripHtml(posting.description) : null;
      if (!description) continue;
      return { title, companyName, description };
    }
    return null;
  }

  // src/capture/extractors/linkedin.ts
  var TITLE_SELECTORS = [
    ".job-details-jobs-unified-top-card__job-title",
    ".jobs-unified-top-card__job-title",
    "h1.t-24"
  ];
  var COMPANY_SELECTORS = [
    ".job-details-jobs-unified-top-card__company-name",
    ".jobs-unified-top-card__company-name"
  ];
  var DESCRIPTION_SELECTORS = [".jobs-description__content", "#job-details", ".jobs-box__html-content"];
  function extractLinkedIn(doc) {
    const jsonLd = extractJobPostingJsonLd(doc);
    if (jsonLd?.description) {
      return {
        title: jsonLd.title,
        companyName: jsonLd.companyName,
        description: jsonLd.description,
        fromJsonLd: true,
        fromKnownContainer: false
      };
    }
    const description = queryText(doc, DESCRIPTION_SELECTORS);
    const title = queryText(doc, TITLE_SELECTORS);
    const companyName = queryText(doc, COMPANY_SELECTORS);
    return {
      title,
      companyName,
      description: description ? cleanText(description) : null,
      fromJsonLd: false,
      fromKnownContainer: description !== null
    };
  }

  // src/capture/extractors/indeed.ts
  var TITLE_SELECTORS2 = [
    '[data-testid="jobsearch-JobInfoHeader-title"]',
    ".jobsearch-JobInfoHeader-title",
    "h1"
  ];
  var COMPANY_SELECTORS2 = [
    '[data-testid="inlineHeader-companyName"]',
    ".jobsearch-InlineCompanyRating"
  ];
  var DESCRIPTION_SELECTORS2 = ["#jobDescriptionText"];
  function extractIndeed(doc) {
    const jsonLd = extractJobPostingJsonLd(doc);
    if (jsonLd?.description) {
      return {
        title: jsonLd.title,
        companyName: jsonLd.companyName,
        description: jsonLd.description,
        fromJsonLd: true,
        fromKnownContainer: false
      };
    }
    const description = queryText(doc, DESCRIPTION_SELECTORS2);
    const title = queryText(doc, TITLE_SELECTORS2);
    const companyName = queryText(doc, COMPANY_SELECTORS2);
    return {
      title,
      companyName,
      description: description ? cleanText(description) : null,
      fromJsonLd: false,
      fromKnownContainer: description !== null
    };
  }

  // src/capture/extractors/generic.ts
  var CONTAINER_SELECTORS = [
    "main",
    "article",
    '[role="main"]',
    '[class*="job-description" i]',
    '[class*="jobdescription" i]',
    '[id*="job-description" i]',
    '[class*="posting-description" i]'
  ];
  var TITLE_SELECTOR = "h1";
  function isNoise(el) {
    return NOISE_SELECTORS.some((noise) => el.closest(noise));
  }
  function extractGeneric(doc) {
    const jsonLd = extractJobPostingJsonLd(doc);
    if (jsonLd?.description) {
      return {
        title: jsonLd.title,
        companyName: jsonLd.companyName,
        description: jsonLd.description,
        fromJsonLd: true,
        fromKnownContainer: false
      };
    }
    let best = null;
    for (const selector of CONTAINER_SELECTORS) {
      for (const el of Array.from(doc.querySelectorAll(selector))) {
        if (isNoise(el)) continue;
        const text = cleanText(el.textContent ?? "");
        if (text.length < 50) continue;
        if (!best || text.length > best.text.length) {
          best = { text, matchedNamedContainer: selector !== "main" && selector !== '[role="main"]' };
        }
      }
    }
    const title = doc.querySelector(TITLE_SELECTOR);
    const titleText = title && !isNoise(title) ? cleanText(title.textContent ?? "") : null;
    const ogSite = doc.querySelector('meta[property="og:site_name"]');
    const companyName = ogSite ? cleanText(ogSite.getAttribute("content") ?? "") || null : null;
    return {
      title: titleText || null,
      companyName,
      description: best?.text ?? null,
      fromJsonLd: false,
      fromKnownContainer: best?.matchedNamedContainer ?? false
    };
  }

  // src/capture/confidence.ts
  var MIN_DESCRIPTION_CHARS = 200;
  var ACCEPT_THRESHOLD = 0.65;
  function scoreConfidence(input) {
    const signals = [];
    let score = 0;
    if (input.descriptionLength < MIN_DESCRIPTION_CHARS) {
      return { score: 0, signals: ["description_too_short"], accepted: false };
    }
    score += 0.5;
    signals.push("substantial_description");
    if (input.hasTitle) {
      score += 0.15;
      signals.push("title_detected");
    }
    if (input.hasCompany) {
      score += 0.15;
      signals.push("company_detected");
    }
    if (input.fromJsonLd) {
      score += 0.2;
      signals.push("json_ld_job_posting");
    }
    if (input.fromKnownContainer) {
      score += 0.15;
      signals.push("known_description_container");
    }
    score = Math.min(score, 1);
    return { score, signals, accepted: score >= ACCEPT_THRESHOLD };
  }

  // src/capture/index.ts
  function captureJobFromPage(hostname, doc, url) {
    const sourceDomain = detectSourceDomain(hostname);
    const site = sourceDomain === "linkedin" ? extractLinkedIn(doc) : sourceDomain === "indeed" ? extractIndeed(doc) : extractGeneric(doc);
    const result = site.description || sourceDomain === "other" ? site : extractGeneric(doc);
    const descriptionLength = result.description?.length ?? 0;
    const confidence = scoreConfidence({
      descriptionLength,
      hasTitle: Boolean(result.title),
      hasCompany: Boolean(result.companyName),
      fromJsonLd: result.fromJsonLd,
      fromKnownContainer: result.fromKnownContainer
    });
    if (!confidence.accepted || !result.description) {
      return {
        ok: false,
        failure: { reason: descriptionLength === 0 ? "no_description" : "low_confidence" }
      };
    }
    return {
      ok: true,
      capture: {
        jobTitle: result.title,
        companyName: result.companyName,
        jobDescription: result.description,
        jobUrl: url,
        sourceDomain,
        confidence: confidence.score
      }
    };
  }

  // src/content/contentScript.ts
  window.__recruiterCheckCapture = captureJobFromPage(window.location.hostname, document, window.location.href);
})();
